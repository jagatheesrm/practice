// Utility functions
const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-IN', {
        style: 'currency',
        currency: 'INR',
        minimumFractionDigits: 2
    }).format(amount);
};

const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-IN', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
};

// Storage functions
const getExpenses = () => {
    return JSON.parse(localStorage.getItem('expenses') || '[]');
};

const saveExpenses = (expenses) => {
    localStorage.setItem('expenses', JSON.stringify(expenses));
};

// Calculate totals
const calculateTotals = () => {
    const expenses = getExpenses();
    const today = new Date().toISOString().split('T')[0];
    
    const todayTotal = expenses
        .filter(expense => expense.date === today)
        .reduce((sum, expense) => sum + expense.amount, 0);
    
    const overallTotal = expenses
        .reduce((sum, expense) => sum + expense.amount, 0);
    
    document.getElementById('todayTotal').textContent = formatCurrency(todayTotal);
    document.getElementById('overallTotal').textContent = formatCurrency(overallTotal);
};

// Render expenses list
const renderExpenses = () => {
    const expenses = getExpenses();
    const expensesList = document.getElementById('expensesList');
    
    expensesList.innerHTML = expenses.map(expense => `
        <div class="expense-item" data-id="${expense.id}">
            <div class="expense-details">
                <h3>${expense.description}</h3>
                <p>${formatDate(expense.date)}</p>
            </div>
            <div class="expense-amount">
                ${formatCurrency(expense.amount)}
            </div>
            <div class="expense-actions">
                <button onclick="editExpense('${expense.id}')" class="edit-btn">
                    <i class="fas fa-edit"></i>
                </button>
                <button onclick="deleteExpense('${expense.id}')" class="delete-btn">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        </div>
    `).join('');
};

// Add new expense
document.getElementById('expenseForm').addEventListener('submit', (e) => {
    e.preventDefault();
    
    const description = document.getElementById('description').value;
    const amount = parseFloat(document.getElementById('amount').value);
    const date = document.getElementById('expenseDate').value;
    
    const expenses = getExpenses();
    expenses.push({
        id: Date.now().toString(),
        description,
        amount,
        date
    });
    
    saveExpenses(expenses);
    e.target.reset();
    document.getElementById('expenseDate').value = new Date().toISOString().split('T')[0];
    
    renderExpenses();
    calculateTotals();
});

// Edit expense
window.editExpense = (id) => {
    const expenses = getExpenses();
    const expense = expenses.find(e => e.id === id);
    
    if (expense) {
        document.getElementById('description').value = expense.description;
        document.getElementById('amount').value = expense.amount;
        document.getElementById('expenseDate').value = expense.date;
        
        // Remove the old expense
        deleteExpense(id);
    }
};

// Delete expense
window.deleteExpense = (id) => {
    if (confirm('Are you sure you want to delete this expense?')) {
        const expenses = getExpenses().filter(expense => expense.id !== id);
        saveExpenses(expenses);
        renderExpenses();
        calculateTotals();
    }
};

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('expenseDate').value = new Date().toISOString().split('T')[0];
    renderExpenses();
    calculateTotals();
});