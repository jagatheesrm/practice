<?php
class Expense {
    private $conn;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function add($description, $amount, $date) {
        $description = $this->conn->real_escape_string($description);
        $amount = (float)$amount;
        $date = $this->conn->real_escape_string($date);
        return $this->conn->query("INSERT INTO expenses (description, amount, expense_date) VALUES ('$description', $amount, '$date')");
    }

    public function update($id, $description, $amount, $date) {
        $id = (int)$id;
        $description = $this->conn->real_escape_string($description);
        $amount = (float)$amount;
        $date = $this->conn->real_escape_string($date);
        return $this->conn->query("UPDATE expenses SET description='$description', amount=$amount, expense_date='$date' WHERE id=$id");
    }

    public function delete($id) {
        $id = (int)$id;
        return $this->conn->query("DELETE FROM expenses WHERE id=$id");
    }

    public function getAll() {
        return $this->conn->query("SELECT * FROM expenses ORDER BY expense_date DESC");
    }

    public function getTodayTotal() {
        return $this->conn->query("SELECT SUM(amount) AS total FROM expenses WHERE expense_date = CURDATE()")->fetch_assoc()['total'] ?? 0;
    }

    public function getOverallTotal() {
        return $this->conn->query("SELECT SUM(amount) AS total FROM expenses")->fetch_assoc()['total'] ?? 0;
    }
}
?>