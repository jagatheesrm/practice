<?php
require_once 'config/database.php';
require_once 'models/Expense.php';

$database = new Database();
$db = $database->connect();
$expense = new Expense($db);

// Handle POST requests
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_expense'])) {
        $expense->add($_POST['description'], $_POST['amount'], $_POST['expense_date']);
    } elseif (isset($_POST['update_expense'])) {
        $expense->update($_POST['id'], $_POST['description'], $_POST['amount'], $_POST['expense_date']);
    }
    header('Location: index.php');
    exit;
}

// Handle DELETE requests
if (isset($_GET['delete'])) {
    $expense->delete($_GET['delete']);
    header('Location: index.php');
    exit;
}

$expenses = $expense->getAll();
$total_today = $expense->getTodayTotal();
$overall_total = $expense->getOverallTotal();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Expense Tracker</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="container">
        <header>
            <h1><i class="fas fa-wallet"></i> Daily Expense Tracker</h1>
            <div class="totals">
                <div class="total-card">
                    <h3>Today's Total</h3>
                    <p>₹<?= number_format($total_today, 2) ?></p>
                </div>
                <div class="total-card">
                    <h3>Overall Total</h3>
                    <p>₹<?= number_format($overall_total, 2) ?></p>
                </div>
            </div>
        </header>

        <section class="add-expense">
            <h2><i class="fas fa-plus-circle"></i> Add New Expense</h2>
            <form method="POST">
                <div class="form-group">
                    <input type="text" name="description" placeholder="Description" required>
                    <i class="fas fa-pencil-alt input-icon"></i>
                </div>
                <div class="form-group">
                    <input type="number" name="amount" step="0.01" placeholder="Amount" required>
                    <i class="fas fa-rupee-sign input-icon"></i>
                </div>
                <div class="form-group">
                    <input type="date" name="expense_date" value="<?= date('Y-m-d') ?>" required>
                    <i class="fas fa-calendar input-icon"></i>
                </div>
                <button type="submit" name="add_expense">
                    <i class="fas fa-plus"></i> Add Expense
                </button>
            </form>
        </section>

        <section class="expenses-list">
            <h2><i class="fas fa-list"></i> All Expenses</h2>
            <div id="expensesList">
                <?php while ($row = $expenses->fetch_assoc()): ?>
                    <div class="expense-item">
                        <div class="expense-details">
                            <h3><?= htmlspecialchars($row['description']) ?></h3>
                            <p><?= date('F j, Y', strtotime($row['expense_date'])) ?></p>
                        </div>
                        <div class="expense-amount">
                            ₹<?= number_format($row['amount'], 2) ?>
                        </div>
                        <div class="expense-actions">
                            <button onclick="showEditForm(<?= $row['id'] ?>, '<?= htmlspecialchars($row['description']) ?>', <?= $row['amount'] ?>, '<?= $row['expense_date'] ?>')" class="edit-btn">
                                <i class="fas fa-edit"></i>
                            </button>
                            <a href="?delete=<?= $row['id'] ?>" onclick="return confirm('Are you sure?')" class="delete-btn">
                                <i class="fas fa-trash"></i>
                            </a>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
        </section>
    </div>

    <!-- Edit Modal -->
    <div id="editModal" class="modal">
        <div class="modal-content">
            <h2><i class="fas fa-edit"></i> Edit Expense</h2>
            <form method="POST">
                <input type="hidden" name="id" id="edit_id">
                <div class="form-group">
                    <input type="text" name="description" id="edit_description" required>
                    <i class="fas fa-pencil-alt input-icon"></i>
                </div>
                <div class="form-group">
                    <input type="number" name="amount" id="edit_amount" step="0.01" required>
                    <i class="fas fa-rupee-sign input-icon"></i>
                </div>
                <div class="form-group">
                    <input type="date" name="expense_date" id="edit_date" required>
                    <i class="fas fa-calendar input-icon"></i>
                </div>
                <div class="modal-actions">
                    <button type="submit" name="update_expense">Update</button>
                    <button type="button" onclick="closeEditModal()">Cancel</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function showEditForm(id, description, amount, date) {
            document.getElementById('edit_id').value = id;
            document.getElementById('edit_description').value = description;
            document.getElementById('edit_amount').value = amount;
            document.getElementById('edit_date').value = date;
            document.getElementById('editModal').style.display = 'block';
        }

        function closeEditModal() {
            document.getElementById('editModal').style.display = 'none';
        }
    </script>
</body>
</html>