<?php
class Database {
    private $host = '154.41.233.204';
    private $username = 'u404546457_j';
    private $password = 'Jagathees@07';
    private $database = 'u404546457_personal';
    private $conn;

    public function connect() {
        $this->conn = new mysqli($this->host, $this->username, $this->password, $this->database);
        if ($this->conn->connect_error) {
            die("Connection failed: " . $this->conn->connect_error);
        }
        return $this->conn;
    }
}
?>